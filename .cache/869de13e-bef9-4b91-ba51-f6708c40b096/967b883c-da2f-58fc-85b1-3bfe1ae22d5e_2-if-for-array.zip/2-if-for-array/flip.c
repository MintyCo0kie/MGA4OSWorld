//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>

//typedef long long ll;
int main(){
    int n=0;
    scanf("%d",&n);
    int bit[100000]={0};
    int i=0,j=0;

    //printf("%d",t);
    for(i=1;i<= n/2;i++){
        for(j=i;j<=n;j++){
            if(j%i==0){
                if(bit[j]==0){
                    bit[j]=1;
                } else{
                    bit[j]=0;
                }
            }
        }
    }
    for(;i<=n;i++) {
        if (bit[i] == 0) {
            bit[i] = 1;
        } else {
            bit[i] = 0;
        }
    }
        for(i=1;i<=n;i++){
            if(bit[i]==1){
                printf("%d ",i);
            }
        }

    return 0;
}
