//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
typedef long long ll;
int main(){
    int n=0;
    scanf("%d",&n);
    int m=0;
    ll a=0;
    ll sum1=0,sum2=0;
    while(n--){
        scanf("%d %lld",&m,&a);
        if (m==1){
            sum1+=a;
        }else{
            sum2+=a;
        }
    }
    printf("%lld",sum2-sum1);
    return 0;
}
