//
// Created by 陈 on 2021/10/18.
//
#include <stdio.h>
int main(){
    int year = 0;
    scanf("%d",&year);
    if ((year % 4 == 0 && year % 100 != 0)||(year % 400 ==0)){
        printf("The year %d is a leap year.\n",year);
    }else{

    }
    return 0;
}

