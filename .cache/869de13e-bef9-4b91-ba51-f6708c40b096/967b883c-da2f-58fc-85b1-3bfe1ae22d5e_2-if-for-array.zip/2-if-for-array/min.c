//
// Created by 陈 on 2021/10/18.
//
#include <stdio.h>
int main(){
    int numbers[5] = {0};
    for(int i=0; i<5; i++){
        scanf("%d",&numbers[i]);
    }
    int min = numbers[0];
    for(int i = 1; i<5; i++){
        if (min > numbers[i]){
            min = numbers[i];
        }
    }
    printf("%d\n",min);
    return 0;
}
