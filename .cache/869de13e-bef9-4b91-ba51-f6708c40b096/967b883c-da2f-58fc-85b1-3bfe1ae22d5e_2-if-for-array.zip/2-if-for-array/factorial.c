//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
typedef long long ll;
ll number[100010]={1};
ll fib[100010]={1};
int main(){
    ll n=0;
    scanf("%lld",&n);
    ll i=1;
    for(i=1;i<=n;i++){
        if(i==1){
            fib[1]=1;
        }else {
            fib[i] = fib[(i - 1)] * (i % 10007);
            if(fib[i]>10007){
                fib[i]%=10007;
            }
            //printf("%lld\n", fib[i]);
        }
    }
    for(i=1;i<=n;i++){
        number[i]=fib[i]%10007;
    }
    ll sum=0;
    for(i=1;i<=n;i++){
        sum+=number[i];
    }
    //printf("%lld\n",sum);
    printf("%lld",sum%10007);
    return 0;
}
