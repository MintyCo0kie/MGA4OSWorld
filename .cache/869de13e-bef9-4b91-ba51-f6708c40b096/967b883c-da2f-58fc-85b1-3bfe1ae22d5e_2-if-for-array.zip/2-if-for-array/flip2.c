//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
#include <math.h>

typedef long long ll;
int main(){
    ll n=0;
    scanf("%lld",&n);
    int i=0;
    for(i=1;i<=n;i++){
        double t= sqrt(i);
        double integer=floor(t);
        if (t==integer){
            printf("%lld ",i);
        }
    }
    return 0;
}

