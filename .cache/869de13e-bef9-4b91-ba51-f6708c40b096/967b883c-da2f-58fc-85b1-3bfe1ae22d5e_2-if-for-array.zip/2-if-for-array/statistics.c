//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
int main(){
    int n=0;
    scanf("%d",&n);
    char str[100]={0};
    int i=0,j=0;
    for(i=0;i<=n;i++){
        scanf("%c",&str[i]);
    }
    int number[30]={0};
    int t=0;
    int max=0;
    for(i=0;i<=n;i++){
        t=(int)str[i];
        //printf("%d\n",t);
        number[t-96]++;
    }
    //printf("%d",number[5]);
    for(i=1;i<=26;i++) {
        if (number[i] > max) {
            max = number[i];
            //printf("%d", max);
        }
    }
    char table[max][30];
    for(i=0;i<26;i++){
        for(j=0;j<max;j++){
            if(max-j<=number[i+1]){
                table[j][i]='=';
            }else{
                table[j][i]=' ';
            }
        }
    }
    for(i=0;i<max;i++){
        printf(" ");
        for(j=0;j<26;j++){
            printf("%c",table[i][j]);
            printf("  ");
        }
        printf("\n");
    }
    for(i=0;i<26;i++){
        printf("---");
    }
    printf("\n");
    for(i=0;i<26;i++){
        printf(" %c ",i+97);
    }
    return 0;
}
