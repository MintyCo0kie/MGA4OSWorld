//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
int main(){
    long long n=0;
    long long number=0;
    long long sum=0;
    scanf("%lld",&n);
    int i=0;
    for(i=0;i<n;i++){
        scanf("%lld",&number);
        sum+=number*(n-i);
    }
    printf("%lld",sum);
    return 0;
}
