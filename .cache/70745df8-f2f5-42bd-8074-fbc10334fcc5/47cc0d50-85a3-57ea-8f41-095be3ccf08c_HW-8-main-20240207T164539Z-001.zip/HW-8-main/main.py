import controller

controller.button_click()