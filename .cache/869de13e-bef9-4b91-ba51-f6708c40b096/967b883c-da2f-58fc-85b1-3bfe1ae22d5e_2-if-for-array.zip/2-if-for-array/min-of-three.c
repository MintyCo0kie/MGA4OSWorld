//
// Created by 陈 on 2021/10/18.
//
#include <stdio.h>
int main(){
    int a =0,b = 0,c=0;
    int min;

    scanf("%d%d%d",&a,&b,&c);

    if (a>=b){
        if(b>=c){
            min=c;
        }else{
            min=b;
        }
    }else{
        if(a>=c){
            min=c;
        }else{
            min=a;
        }
    }
    printf("%d",min);
    return 0;
}
