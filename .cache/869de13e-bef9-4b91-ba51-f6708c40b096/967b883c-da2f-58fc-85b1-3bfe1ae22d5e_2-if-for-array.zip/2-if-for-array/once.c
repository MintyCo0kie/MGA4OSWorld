//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
#include <math.h>
typedef long long ll;
int main(){
    ll n=0;
    scanf("%lld",&n);

    int numbers[100000]={0};
    int i=0;
    ll num;
    for(i=0;i<2*n-1;i++){
        scanf("%lld",&num);
        numbers[num-1]+=1;
    }
    int j=0;
    for(j=0;j<n;j++) {
        if (numbers[j] == 1){
            printf("%lld",j+1);
        }
    }
    return 0;
}
