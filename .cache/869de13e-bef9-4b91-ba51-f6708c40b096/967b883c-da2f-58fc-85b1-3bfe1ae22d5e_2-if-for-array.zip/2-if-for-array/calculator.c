//
// Created by 陈 on 2021/10/22.
//
#include <stdio.h>
#include <math.h>
int main(){
    int a=0,b=0;
    char op[5]={0};
    while(scanf("%d %s %d",&a,&op,&b)!=EOF){
        if(op[0]=='+'){
            printf("%d\n",a+b);
        }else if(op[0]=='-'){
            printf("%d\n",a-b);
        }else if(op[0]=='*'&&op[1]==0){
            printf("%d\n",a*b);
        }else if(op[0]=='/'&&op[1]==0){
            printf("%d\n",a/b);
        }else if(op[0]=='/'&&op[1]=='*'){
            printf("%.3f\n",1.0*a/b);
        }else if(op[0]=='*'&&op[1]=='*'){
            printf("%d\n",(int)pow(a,b));
        }else{
            if(a<0){
                printf("-");
                a=(-1)*a;
            }
            printf("%d\n",a%b);
        }
    }
    return 0;
}
